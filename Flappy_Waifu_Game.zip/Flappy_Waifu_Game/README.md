# ProjectFlappyWaifu

Flappy Waifu ist ein Minispiel für PC, bei dem der Spieler mit der Spielfigur namens Waifu Gegenständen ausweichen muss.

![Chitanda_main](https://user-images.githubusercontent.com/68156445/111909755-d5980200-8a5e-11eb-94b4-6da2fbc27ae3.png)

![Flow_Chart](https://user-images.githubusercontent.com/68156445/111909780-e6e10e80-8a5e-11eb-894e-c4e1c48cd2ad.png)


-------------------------------------------------

HINWEIS: Zum Ausführen der Software gibt es zwei Wege. 1: Die von uns  zur Verfügung gestellte gepackte Version herunterladen und unter dem Ordner "dist" die main.exe ausführen (Dabei kann es dazu führen, dass die exe von dem Antivirenprogramm abgefangen wird). 
2: Den Ordner bei Github herunterladen und die main.py bei VS code öffnen. Bevor der Code ausgeführt werden kann, muss die Ordnerstruktur bei Code geladen werden. Falls es bei beiden Methoden Probleme geben sollte, können Sie uns kontaktieren.

Zu 2): Falls eine Settings.Json Datei im .vscode existiert, diese bitte vorher löschen, da der Pfad von Can angegeben ist.

-------------------------------------------------

Ein Spiel entwickelt von Can-Luca Guiseppe Russo und Pascal Ziesemann.

Projektrealisierung des Wahlkurses Programmierung in Python bei Prof. Dr. Michael Arnold.

Abgabedatum 23.03.2021.

Erstellt in der Leibniz Fachhochschule.
